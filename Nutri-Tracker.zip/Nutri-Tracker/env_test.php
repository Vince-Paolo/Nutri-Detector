<?php
echo getenv("CLARIFAI_PAT") ? "PAT OK" : "PAT NOT FOUND";
