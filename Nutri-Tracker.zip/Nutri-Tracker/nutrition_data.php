<?php
$nutrition = [
  "apple" => ["calories" => 95,  "protein" => 0.5, "carbs" => 25, "fat" => 0.3],
  "banana" => ["calories" => 105, "protein" => 1.3, "carbs" => 27, "fat" => 0.4],
  "fried chicken" => ["calories" => 320, "protein" => 30,  "carbs" => 8,  "fat" => 20],
  "burger" => ["calories" => 550, "protein" => 25,  "carbs" => 45, "fat" => 30],
  "rice" => ["calories" => 206, "protein" => 4.3, "carbs" => 45, "fat" => 0.4],
];
    